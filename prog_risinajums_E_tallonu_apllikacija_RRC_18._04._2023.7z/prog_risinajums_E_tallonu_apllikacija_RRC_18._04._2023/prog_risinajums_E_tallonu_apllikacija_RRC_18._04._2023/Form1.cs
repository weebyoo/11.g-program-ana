﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using QRCoder;
using System.IO;

namespace prog_risinajums_E_tallonu_apllikacija_RRC_18._04._2023
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            var allChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            var resultToken = new string(Enumerable.Repeat(allChar, 20).Select(token => token[random.Next(token.Length)]).ToArray());
            string authToken = resultToken.ToString();
            
            
            
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(authToken, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(10, "#000000", "#FFFFFF");
            
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.Image = qrCodeImage;
            
            int uses = Convert.ToInt32(tb_uses.Text);
            string price = Convert.ToString(uses * 3);
            lable_price.Text = price + "€";
            string uses2 =Convert.ToString(uses);
            string[] writefile = new String[] { authToken, uses2};

            if (!File.Exists("tokensave.txt"))
            {
                File.WriteAllLines("tokensave.txt", writefile) ;
            
            }
            else
            {

                File.AppendAllText("tokensave.txt", contents: Environment.NewLine + writefile);
            }
            

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamReader file = new StreamReader("tokensave.txt");
            string line;
            while ((line = file.ReadLine()) !=null)
           
            {

                if (line.Contains(TB_linecount.Text + "1.nr "))
                {
                    lable_string.Text = line;
                }
                else
                {
                    lable_string.Text = "nav";
                }
            }
        }
    }
}
